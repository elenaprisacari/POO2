package application;

import javafx.beans.value.ObservableValue;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;

public class Controler {

	@FXML
	ListView<Student> StudentsList;
	
	@FXML
	Label NameLabel, MediaLabel, CourseLabel;
	
	@FXML
	TextField NameField;
	
	@FXML
	Spinner<Double> MediaSpinner;
	SpinnerValueFactory<Double> MediaFactory = new SpinnerValueFactory.DoubleSpinnerValueFactory(1, 10, 1, 0.1);
	
	@FXML
	Spinner<Integer> CourseSpinner;
	SpinnerValueFactory<Integer> CourseFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 4, 1);

	@FXML
	Button AddStudentButt, DelStudentButt, PlusOne, MinusOne;
	
	public void initialize() {
		MediaSpinner.setValueFactory(MediaFactory);
		CourseSpinner.setValueFactory(CourseFactory);
		
		StudentsList.getItems().add(new Student("Vadim", 2, 7.5));
		
		StudentsList.getSelectionModel().selectedItemProperty().addListener(new javafx.beans.value.ChangeListener<Student>() {

			@Override
			public void changed(ObservableValue<? extends Student> arg0, Student arg1, Student arg2) {
				if(arg2 != null) 
				{
					NameLabel.setText(arg2.Name);
					MediaLabel.setText(arg2.Media.toString());
					CourseLabel.setText(arg2.Course.toString());
				}
				else
				{
					NameLabel.setText("");
					MediaLabel.setText("");
					CourseLabel.setText("");
				}
			}
		});
    }
	
	@FXML
	private void AddStudentButtClick(ActionEvent event) {
		if(NameField.getLength() > 5)
			StudentsList.getItems().add(new Student(NameField.getText(), CourseSpinner.getValue(), MediaSpinner.getValue()));
		else
			new Alert(Alert.AlertType.INFORMATION, "������ �� �����!").showAndWait();
	}
	
	@FXML
	private void DellStudentButtClick(ActionEvent event) {
		int selInd = StudentsList.getSelectionModel().getSelectedIndex();;
		if(selInd >= 0)
			StudentsList.getItems().remove(selInd);
	}
	
	@FXML
	private void PlusOneClick(ActionEvent event) {
		MediaSpinner.increment(10);
	}
	
	@FXML
	private void MinusOneClick(ActionEvent event) {
		MediaSpinner.decrement(10);
	}
}
