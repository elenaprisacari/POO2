package application;

public class Student {
	String Name;
	Integer Course;
	Double Media;
	
	public Student(String name, Integer course, Double media) {
		this.Name = name;
		this.Course = course;
		this.Media = media;
	}
	
	@Override
	public String toString() {
		return Name;
	}
}
